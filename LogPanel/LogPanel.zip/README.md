# AT Framework

Простой фреймворк UI-автотестов на Selenium 4 + JUnit 5.

## Стек
- Java 21 (source/target), запускается на JDK 21+
- Maven 3.9+
- Selenium 4.27 (Selenium Manager сам подтягивает драйверы — WebDriverManager не нужен)
- JUnit Jupiter 5.11
- SLF4J + Logback

## Структура

```
src/test/
├── java/com/example/at/
│   ├── config/TestConfig.java        # чтение настроек (sys props → env → properties)
│   ├── driver/DriverFactory.java     # создание WebDriver (Chrome/Firefox)
│   ├── logging/                      # localhost log sink + активация Chrome Side Panel
│   ├── base/BaseTest.java            # @BeforeEach/@AfterEach, lifecycle драйвера
│   ├── pages/                        # Page Objects
│   │   ├── BasePage.java
│   │   ├── DuckDuckGoHomePage.java
│   │   └── DuckDuckGoSearchResultsPage.java
│   └── tests/
│       └── DuckDuckGoSearchTest.java # пример теста
└── resources/
    ├── config.properties
    ├── extensions/aut-logs-sidepanel/ # Chrome extension с side_panel UI
    └── logback-test.xml
```

## Запуск

```bash
# все тесты: Chrome GUI, mobile emulation, live-log panel рядом с AUT
mvn test

# headless
mvn test -Dheadless=true -Dlog.panel.enabled=false

# Firefox
mvn test -Dbrowser=firefox -Dlog.panel.enabled=false -Dchrome.mobile.enabled=false

# конкретный тест
mvn test -Dtest=DuckDuckGoSearchTest

# временно отключить панель или mobile emulation
mvn test -Dlog.panel.enabled=false
mvn test -Dchrome.mobile.enabled=false
```

## Предусловия

Для запуска тестов нужны:

- JDK 21+;
- Maven 3.9+;
- доступ в интернет к `https://duckduckgo.com/`;
- доступный Selenium Manager или уже закэшированный ChromeDriver;
- `src/test/resources/config.properties` в test resources.

Для запуска `DuckDuckGoSearchTest` именно в мобильном режиме вместе с Chrome Side Panel должны выполняться дополнительные условия:

- `browser=chrome`;
- `headless=false`;
- `log.panel.enabled=true`;
- `chrome.mobile.enabled=true`;
- доступен Chrome for Testing или Chromium с поддержкой Side Panel API; расширение требует Chrome `116+`;
- если браузер не найден автоматически, задайте `-Dchrome.binary.path=/path/to/browser`;
- порт `127.0.0.1:17654` свободен, потому что панель читает live-log с `http://127.0.0.1:17654/logs`;
- окно Chrome достаточно широкое для mobile viewport и боковой панели; по умолчанию используется `browser.window.width=1400`;
- запуск идет в GUI-сессии, потому что Chrome Side Panel является частью UI браузера и визуально не работает в headless.

Команды ниже отключают панель или делают ее невозможной:

```bash
mvn test -Dheadless=true
mvn test -Dbrowser=firefox
mvn test -Dlog.panel.enabled=false
```

Важно: Side Panel не является частью DOM страницы DuckDuckGo. Это штатная боковая область Chrome, открытая расширением в том же окне, поэтому Selenium-скриншот страницы не захватывает ее полностью. Для проверки расположения панели рядом с AUT используйте системный скриншот окна Chrome.

## Конфигурация

Приоритет: system property (`-Dkey=value`) → env var (`KEY_NAME`) → `config.properties` → default.

| Ключ | По умолчанию | Назначение |
|---|---|---|
| `browser` | `chrome` | `chrome` или `firefox` |
| `headless` | `false` | запуск без GUI |
| `base.url` | `https://duckduckgo.com/` | стартовый URL |
| `explicit.wait.seconds` | `10` | таймаут WebDriverWait |
| `page.load.timeout.seconds` | `30` | таймаут загрузки страницы |
| `log.panel.enabled` | `true` | включает live-log панель через Chrome Side Panel |
| `log.panel.server.port` | `17654` | localhost-порт, с которого панель читает live-лог |
| `chrome.binary.path` | пусто | путь к Chrome for Testing/Chromium; если пусто, ищется в локальном cache |
| `chrome.mobile.enabled` | `true` | включает mobile emulation через `deviceMetrics` / `clientHints` |
| `browser.window.x` | `40` | X-позиция окна AUT |
| `browser.window.y` | `80` | Y-позиция окна AUT |
| `browser.window.width` | `1400` | ширина окна браузера: mobile viewport + Chrome Side Panel |
| `browser.window.height` | `1100` | высота окна браузера |

## Live-Log Панель

Реализация сделана как настоящее расширение Chrome Side Panel в том же окне, где открыт AUT:

- Java поднимает локальный endpoint `http://127.0.0.1:17654/logs`;
- `LogPanelAppender` пишет тестовые логи в `BrowserLogSink`;
- Selenium запускает Chrome for Testing/Chromium и грузит unpacked-расширение из `src/test/resources/extensions/aut-logs-sidepanel/`;
- extension page вызывает `chrome.sidePanel.open()`, поэтому лог открывается в боковой панели Chrome, а не отдельной вкладкой или окном;
- `sidepanel.html` / `sidepanel.js` читают `/logs` каждые 500 мс и показывают новые записи по мере выполнения теста.

Что важно:

- режим работает только в headed Chrome;
- для Firefox и headless отключайте `log.panel.enabled`;
- обычный branded Chrome может игнорировать `--load-extension`, поэтому по умолчанию используется Chrome for Testing из `~/.cache/at/chrome-for-testing/` или `~/.cache/puppeteer/chrome/`;
- панель не внедряется в страницу AUT и не перекрывает mobile viewport, она занимает штатную боковую область Chrome;
- размер/позицию окна можно подстроить через `browser.window.*`.

## Добавление нового теста

1. Создайте Page Object в `pages/`, наследуя `BasePage`.
2. Создайте тест-класс в `tests/`, наследуя `BaseTest` — драйвер и wait уже инициализированы.
3. Используйте `@Test` + `@DisplayName` из JUnit 5.

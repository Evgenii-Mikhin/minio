const TRIGGER_FRAME_ID = "at-log-panel-sidepanel-trigger-frame";

function ensureTrigger() {
  if (document.getElementById(TRIGGER_FRAME_ID)) {
    return;
  }

  const frame = document.createElement("iframe");
  frame.id = TRIGGER_FRAME_ID;
  frame.title = "AT Log Panel trigger";
  frame.src = chrome.runtime.getURL("trigger.html");
  frame.style.cssText = [
    "position:fixed",
    "top:0",
    "right:0",
    "width:8px",
    "height:8px",
    "opacity:0",
    "pointer-events:auto",
    "z-index:2147483647",
    "border:0",
    "padding:0",
    "margin:0",
    "background:transparent",
  ].join(";");

  document.documentElement.appendChild(frame);
}

ensureTrigger();

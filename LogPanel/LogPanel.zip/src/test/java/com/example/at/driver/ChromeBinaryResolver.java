package com.example.at.driver;

import com.example.at.config.TestConfig;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;

final class ChromeBinaryResolver {

    private static final String CHROME_FOR_TESTING_BINARY =
            "chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing";

    private ChromeBinaryResolver() {
    }

    static Optional<Path> resolveBrowserBinary() {
        String configuredBinary = TestConfig.chromeBinaryPath();
        if (!configuredBinary.isBlank()) {
            return Optional.of(validate(Path.of(configuredBinary).toAbsolutePath().normalize()));
        }

        return Stream.of(
                        Path.of(System.getProperty("user.home"), ".cache", "at", "chrome-for-testing"),
                        Path.of(System.getProperty("user.home"), ".cache", "puppeteer", "chrome"),
                        Path.of("/Applications")
                )
                .filter(Files::isDirectory)
                .flatMap(ChromeBinaryResolver::findChromeForTestingBinaries)
                .max(Comparator.comparing(ChromeBinaryResolver::versionKey));
    }

    static Path requireSidePanelBrowserBinary() {
        return resolveBrowserBinary()
                .orElseThrow(() -> new IllegalStateException(
                        "Chrome Side Panel tests require Chrome for Testing or Chromium because regular Chrome "
                                + "does not reliably load unpacked extensions from --load-extension. "
                                + "Install Chrome for Testing or set -Dchrome.binary.path=/path/to/browser"
                ));
    }

    private static Stream<Path> findChromeForTestingBinaries(Path root) {
        try {
            if (root.equals(Path.of("/Applications"))) {
                return Stream.of(root.resolve("Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing"))
                        .filter(Files::isRegularFile);
            }
            return Files.find(root, 8, (path, attrs) ->
                            attrs.isRegularFile() && path.endsWith(CHROME_FOR_TESTING_BINARY))
                    .map(Path::toAbsolutePath)
                    .map(Path::normalize);
        } catch (Exception e) {
            return Stream.empty();
        }
    }

    private static Path validate(Path binary) {
        if (!Files.isRegularFile(binary) || !Files.isExecutable(binary)) {
            throw new IllegalArgumentException("Configured Chrome binary is not executable: " + binary);
        }
        return binary;
    }

    private static String versionKey(Path binary) {
        String path = binary.toString();
        int marker = path.indexOf("chrome-for-testing/");
        if (marker < 0) {
            marker = path.indexOf("mac_arm-");
            if (marker >= 0) {
                return path.substring(marker + "mac_arm-".length());
            }
            return path;
        }
        return path.substring(marker + "chrome-for-testing/".length());
    }
}


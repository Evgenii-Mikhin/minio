package com.example.at.driver;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ChromeBinaryResolverTest {

    @TempDir
    Path tempDir;

    private final String originalChromeBinaryPath = System.getProperty("chrome.binary.path");

    @AfterEach
    void restoreChromeBinaryPath() {
        if (originalChromeBinaryPath == null) {
            System.clearProperty("chrome.binary.path");
        } else {
            System.setProperty("chrome.binary.path", originalChromeBinaryPath);
        }
    }

    @Test
    void usesConfiguredChromeBinaryWhenProvided() throws Exception {
        Path binary = tempDir.resolve("Google Chrome for Testing");
        Files.writeString(binary, "#!/bin/sh\n");
        binary.toFile().setExecutable(true);
        System.setProperty("chrome.binary.path", binary.toString());

        assertEquals(binary.toAbsolutePath().normalize(), ChromeBinaryResolver.resolveBrowserBinary().orElseThrow());
    }

    @Test
    void rejectsConfiguredChromeBinaryWhenItIsNotExecutable() {
        Path missingBinary = tempDir.resolve("missing-chrome");
        System.setProperty("chrome.binary.path", missingBinary.toString());

        assertThrows(IllegalArgumentException.class, ChromeBinaryResolver::resolveBrowserBinary);
    }
}


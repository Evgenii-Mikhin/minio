package com.example.at.logging;

import com.example.at.config.TestConfig;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Owns activation of the Chrome Side Panel log panel for the current test run.
 */
public final class LogPanelController {

    static final By SIDE_PANEL_TRIGGER = By.id("at-log-panel-sidepanel-trigger");
    static final By SIDE_PANEL_TRIGGER_FRAME = By.id("at-log-panel-sidepanel-trigger-frame");

    private LogPanelController() {
    }

    public static void openIfNeeded(WebDriver driver, String url) {
        if (!TestConfig.logPanelEnabled() || BrowserLogSink.isRemoteReady() || !isWebUrl(url)) {
            return;
        }

        openChromeSidePanel(driver);
        BrowserLogSink.activatePanel();
    }

    private static void openChromeSidePanel(WebDriver driver) {
        LogPanelServer.ensureStarted();

        if (clickExtensionTrigger(driver)) {
            return;
        }

        new Actions(driver)
                .keyDown(Keys.COMMAND)
                .keyDown(Keys.SHIFT)
                .sendKeys("y")
                .keyUp(Keys.SHIFT)
                .keyUp(Keys.COMMAND)
                .perform();
    }

    private static boolean clickExtensionTrigger(WebDriver driver) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(SIDE_PANEL_TRIGGER_FRAME));
            wait.until(ExpectedConditions.elementToBeClickable(SIDE_PANEL_TRIGGER)).click();
            return true;
        } catch (RuntimeException e) {
            return false;
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    private static boolean isWebUrl(String url) {
        return url != null && (url.startsWith("http://") || url.startsWith("https://"));
    }
}
